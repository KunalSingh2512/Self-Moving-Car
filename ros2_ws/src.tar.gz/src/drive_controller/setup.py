from setuptools import setup

package_name = 'drive_controller'
package_dir={'': '.'},

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name], 
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='kunal-singh',
    maintainer_email='singhk122007@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'mission_node = drive_controller.mission_node:main',
            'control_node = drive_controller.control_node:main',
        ],
    },
)